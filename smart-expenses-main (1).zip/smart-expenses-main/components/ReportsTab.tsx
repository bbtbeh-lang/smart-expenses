'use client';

import { useState, useMemo } from 'react';
import { Download, TrendingUp, TrendingDown, DollarSign, Search, X, Package, Lock } from 'lucide-react';
import { Transaction, Lang, Tier } from '@/lib/types';
import { Translations } from '@/lib/translations';
import { parseLocalDate, resolveCategoryLabel, csvField, csvTextField } from '@/lib/utils';

interface ReportsTabProps {
  transactions: Transaction[];
  lang: Lang;
  tr: Translations;
  customCategories?: Record<string, string>;
  customIncomeCategories?: Record<string, string>;
  // Same paid-plan-or-gift-code export gate as TaxReportModal and
  // TransactionsTab — this file had two CSV export buttons (monthly
  // report + product/order search) with no tier prop at all, free for
  // everyone.
  tier: Tier;
  hasGiftAccess: boolean;
  onOpenUpgrade: () => void;
}

type ViewMode = 'all' | 'income' | 'expense';

const LABELS = {
  EN: {
    title: '📊 Financial Reports',
    allTime: 'All Time',
    income: 'Income',
    expenses: 'Expenses',
    all: 'All',
    profit: 'Profit',
    topIncomeCats: 'Top Income Categories',
    topExpenseCats: 'Top Expense Categories',
    transactions: 'Transactions',
    exportCSV: 'Export CSV',
    noTransactions: 'No transactions',
    searchTitle: 'Search by Product / Order',
    searchPlaceholder: 'e.g. "Order #1024" or "iPhone case"',
    searchHint: 'Find every income and expense tied to a specific product or order, based on the transaction description.',
    matches: 'matches',
    totalSpent: 'Total Spent',
    totalReceived: 'Total Received',
    netForItem: 'Net for this item',
    exportMatches: 'Export Matches',
    clear: 'Clear',
    noMatches: 'No transactions match your search',
    fromDate: 'From',
    toDate: 'To',
    categoryFilter: 'Category',
    allCategories: 'All categories',
    clearSearch: 'Clear search',
  },
  FR: {
    title: '📊 Rapports financiers',
    allTime: 'Toute la période',
    income: 'Revenus',
    expenses: 'Dépenses',
    all: 'Tout',
    profit: 'Profit',
    topIncomeCats: 'Principales catégories de revenus',
    topExpenseCats: 'Principales catégories de dépenses',
    transactions: 'Transactions',
    exportCSV: 'Exporter en CSV',
    noTransactions: 'Aucune transaction',
    searchTitle: 'Rechercher par produit / commande',
    searchPlaceholder: 'p. ex. « Commande #1024 » ou « Coque iPhone »',
    searchHint: 'Trouvez tous les revenus et dépenses liés à un produit ou une commande précise, selon la description de la transaction.',
    matches: 'résultats',
    totalSpent: 'Total dépensé',
    totalReceived: 'Total reçu',
    netForItem: 'Net pour cet article',
    exportMatches: 'Exporter les résultats',
    clear: 'Effacer',
    noMatches: 'Aucune transaction ne correspond à votre recherche',
    fromDate: 'Du',
    toDate: 'Au',
    categoryFilter: 'Catégorie',
    allCategories: 'Toutes les catégories',
    clearSearch: 'Effacer la recherche',
  },
  FA: {
    title: '📊 گزارش‌های مالی',
    allTime: 'همه زمان‌ها',
    income: 'درآمد',
    expenses: 'هزینه',
    all: 'همه',
    profit: 'سود',
    topIncomeCats: 'دسته‌بندی‌های برتر درآمد',
    topExpenseCats: 'دسته‌بندی‌های برتر هزینه',
    transactions: 'تراکنش‌ها',
    exportCSV: 'خروجی CSV',
    noTransactions: 'تراکنشی وجود ندارد',
    searchTitle: 'جستجو بر اساس محصول / سفارش',
    searchPlaceholder: 'مثلاً «سفارش ۱۰۲۴» یا «کاور آیفون»',
    searchHint: 'همه‌ی درآمدها و هزینه‌های مربوط به یک محصول یا سفارش خاص را بر اساس توضیحات تراکنش پیدا کنید.',
    matches: 'مورد یافت شد',
    totalSpent: 'مجموع هزینه',
    totalReceived: 'مجموع دریافتی',
    netForItem: 'سود خالص این مورد',
    exportMatches: 'خروجی نتایج',
    clear: 'پاک کردن',
    noMatches: 'هیچ تراکنشی با این جستجو مطابقت ندارد',
    fromDate: 'از تاریخ',
    toDate: 'تا تاریخ',
    categoryFilter: 'دسته‌بندی',
    allCategories: 'همه‌ی دسته‌بندی‌ها',
    clearSearch: 'پاک کردن جستجو',
  },
};

// SECURITY: description and category label go through csvTextField
// (neutralizes a leading =/+/-/@ so Excel can't run it as a formula —
// see lib/utils.ts). date/type/amount go through plain csvField since
// they're computed by this app, not free-text: a legitimate negative
// amount string like "-42" must NOT be prefixed, or it stops being a
// number in the spreadsheet.
function exportToCSV(transactions: Transaction[], fileName: string, catLabel: (key: string) => string = k => k) {
  const headers = ['Date', 'Description', 'Category', 'Type', 'Amount'];
  const rows = transactions.map(t => [
    csvField(t.date),
    csvTextField(t.description),
    csvTextField(catLabel(t.category)),
    csvField(t.type),
    csvField(t.type === 'expense' ? `-${t.amount}` : t.amount)
  ]);

  const csv = [headers.map(csvField), ...rows].map(r => r.join(',')).join('\n');
  // Leading UTF-8 BOM so Excel on Windows renders Persian/French
  // characters correctly instead of the system codepage's mojibake.
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${fileName}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function CategoryBreakdown({ title, entries, total, color, catLabel }: { title: string; entries: [string, number][]; total: number; color: string; catLabel: (key: string) => string }) {
  if (entries.length === 0) return null;
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-4 mb-4 shadow-sm">
      <h3 className="text-sm font-bold text-slate-800 mb-3">{title}</h3>
      <div className="space-y-2">
        {entries.map(([cat, amount]) => (
          <div key={cat}>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-600">{catLabel(cat)}</span>
              <span className="font-semibold text-slate-800" dir="ltr">
                {amount.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' })}
              </span>
            </div>
            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${color}`}
                style={{ width: `${total > 0 ? Math.min((amount / total) * 100, 100) : 0}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ReportsTab({ transactions, lang, tr, customCategories = {}, customIncomeCategories = {}, tier, hasGiftAccess, onOpenUpgrade }: ReportsTabProps) {
  const canExport = tier === 'premium' || hasGiftAccess;
  const [selectedMonth, setSelectedMonth] = useState('all');
  const [view, setView] = useState<ViewMode>('all');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const isRtl = lang === 'FA';
  const L = LABELS[lang] ?? LABELS.EN;

  const fmt = (n: number) => n.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });
  // BUG FIX: this used to only check `tr`, so any user-minted custom
  // category (see getOrCreateCategoryKey in lib/utils.ts) showed its raw
  // internal key ("custom_suger_1784775632372") everywhere in this tab —
  // the category filter dropdown, search results, the breakdown list,
  // and the CSV export.
  const catLabel = (key: string) => resolveCategoryLabel(key, tr as unknown as Record<string, string>, customCategories, customIncomeCategories);

  // Get unique months
  const months = useMemo(() => {
    const m = new Set(transactions.map(t => t.date.slice(0, 7)));
    return Array.from(m).sort().reverse();
  }, [transactions]);

  // A custom date range (both fields set) takes over from the month-pill
  // selector entirely — it can span partial months or several full
  // months, which the pills alone can't express. Picking a custom range
  // resets the month selector back to "all" so the two controls never
  // fight each other silently.
  const hasCustomRange = !!(dateFrom && dateTo);

  // Filter by month or custom range
  const monthFiltered = useMemo(() => {
    if (hasCustomRange) return transactions.filter(t => t.date >= dateFrom && t.date <= dateTo);
    if (selectedMonth === 'all') return transactions;
    return transactions.filter(t => t.date.startsWith(selectedMonth));
  }, [transactions, selectedMonth, hasCustomRange, dateFrom, dateTo]);

  // Every category actually present in the current date range, so the
  // filter only ever offers choices that can return results.
  const availableCategories = useMemo(() => {
    const set = new Set(monthFiltered.map(t => t.category));
    return Array.from(set).sort((a, b) => catLabel(a).localeCompare(catLabel(b)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [monthFiltered]);

  // Filter by selected view (income / expense / all) and category, sorted
  // newest-first (same convention as the Transactions tab) — previously
  // this just used whatever order the transactions arrived in, which
  // wasn't necessarily chronological.
  const filtered = useMemo(() => {
    let list = view === 'all' ? monthFiltered : monthFiltered.filter(t => t.type === view);
    if (categoryFilter !== 'all') list = list.filter(t => t.category === categoryFilter);
    return [...list].sort((a, b) => b.date.localeCompare(a.date));
  }, [monthFiltered, view, categoryFilter]);

  // Calculate totals (always computed on the month-filtered set so the summary cards stay consistent)
  const income = monthFiltered.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const expenses = monthFiltered.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const profit = income - expenses;

  // Category breakdowns, split cleanly between income and expense
  const expenseCategoryBreakdown = useMemo(() => {
    const cats: Record<string, number> = {};
    monthFiltered.filter(t => t.type === 'expense').forEach(t => {
      cats[t.category] = (cats[t.category] || 0) + t.amount;
    });
    return Object.entries(cats).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [monthFiltered]);

  const incomeCategoryBreakdown = useMemo(() => {
    const cats: Record<string, number> = {};
    monthFiltered.filter(t => t.type === 'income').forEach(t => {
      cats[t.category] = (cats[t.category] || 0) + t.amount;
    });
    return Object.entries(cats).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [monthFiltered]);

  // Product / order search — matches against the transaction description across ALL transactions
  // (not limited to the selected month) so a full history for one product/order can be pulled at once.
  const searchResults = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [];
    return transactions.filter(t => t.description.toLowerCase().includes(q)).sort((a, b) => b.date.localeCompare(a.date));
  }, [transactions, search]);

  const searchSpent = searchResults.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const searchReceived = searchResults.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);

  const renderRow = (t: Transaction) => (
    <div key={t.id} className="flex items-center justify-between px-4 py-2.5">
      <div>
        <p className="text-xs font-semibold text-slate-800">{t.description}</p>
        <p className="text-xs text-slate-500">{t.date} · {catLabel(t.category)}</p>
      </div>
      <span className={`text-xs font-bold ${t.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`} dir="ltr">
        {t.type === 'income' ? '+' : '-'}{fmt(t.amount)}
      </span>
    </div>
  );

  return (
    <div className="px-4 lg:px-6 pt-4 pb-28 lg:pb-12 max-w-2xl lg:max-w-4xl mx-auto" dir={isRtl ? 'rtl' : 'ltr'}>
      <h2 className="text-xl font-bold text-slate-900 mb-4">{L.title}</h2>

      {/* Month selector — a plain dropdown rather than one pill per
          month, since a pill row keeps growing sideways forever as
          transaction history accumulates across years. */}
      <div className="mb-3">
        <select
          value={hasCustomRange ? '' : selectedMonth}
          onChange={e => { setSelectedMonth(e.target.value || 'all'); setDateFrom(''); setDateTo(''); }}
          className="w-full sm:w-64 px-3 py-2 bg-slate-100 border-0 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-400"
        >
          <option value="all">{L.allTime}</option>
          {months.map(m => (
            <option key={m} value={m}>
              {parseLocalDate(m + '-01').toLocaleString('default', { month: 'long', year: 'numeric' })}
            </option>
          ))}
        </select>
      </div>

      {/* Custom date range + category filter */}
      <div className="grid grid-cols-2 gap-2 mb-2">
        <div>
          <label className="text-[10px] font-semibold text-slate-400 uppercase mb-1 block">{L.fromDate}</label>
          <input
            type="date"
            value={dateFrom}
            onChange={e => setDateFrom(e.target.value)}
            className="w-full px-2.5 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-400"
            dir="ltr"
          />
        </div>
        <div>
          <label className="text-[10px] font-semibold text-slate-400 uppercase mb-1 block">{L.toDate}</label>
          <input
            type="date"
            value={dateTo}
            onChange={e => setDateTo(e.target.value)}
            className="w-full px-2.5 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-400"
            dir="ltr"
          />
        </div>
      </div>
      <div className="mb-4">
        <label className="text-[10px] font-semibold text-slate-400 uppercase mb-1 block">{L.categoryFilter}</label>
        <select
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          className="w-full px-2.5 py-2 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-400"
        >
          <option value="all">{L.allCategories}</option>
          {availableCategories.map(c => (
            <option key={c} value={c}>{catLabel(c)}</option>
          ))}
        </select>
      </div>

      {/* Income / Expense / All view toggle */}
      <div className="flex gap-1.5 mb-4 bg-slate-100 rounded-xl p-1">
        {(['all', 'income', 'expense'] as ViewMode[]).map(v => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              view === v
                ? v === 'income'
                  ? 'bg-emerald-500 text-white shadow-sm'
                  : v === 'expense'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'bg-white text-slate-800 shadow-sm'
                : 'text-slate-500'
            }`}
          >
            {v === 'all' ? L.all : v === 'income' ? L.income : L.expenses}
          </button>
        ))}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-emerald-50 rounded-2xl p-3">
          <div className="flex items-center gap-1 mb-1">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
            <span className="text-[10px] font-semibold text-emerald-600 uppercase">{L.income}</span>
          </div>
          <p className="text-sm font-bold text-emerald-700" dir="ltr">{fmt(income)}</p>
        </div>
        <div className="bg-rose-50 rounded-2xl p-3">
          <div className="flex items-center gap-1 mb-1">
            <TrendingDown className="w-3.5 h-3.5 text-rose-600" />
            <span className="text-[10px] font-semibold text-rose-600 uppercase">{L.expenses}</span>
          </div>
          <p className="text-sm font-bold text-rose-700" dir="ltr">{fmt(expenses)}</p>
        </div>
        <div className={`rounded-2xl p-3 ${profit >= 0 ? 'bg-indigo-50' : 'bg-rose-50'}`}>
          <div className="flex items-center gap-1 mb-1">
            <DollarSign className="w-3.5 h-3.5 text-indigo-600" />
            <span className="text-[10px] font-semibold text-indigo-600 uppercase">{L.profit}</span>
          </div>
          <p className={`text-sm font-bold ${profit >= 0 ? 'text-indigo-700' : 'text-rose-600'}`} dir="ltr">{fmt(profit)}</p>
        </div>
      </div>

      {/* Category breakdowns — shown independently per type so income & expense reporting stay fully separated */}
      {(view === 'all' || view === 'income') && (
        <CategoryBreakdown title={L.topIncomeCats} entries={incomeCategoryBreakdown} total={income} color="bg-emerald-400" catLabel={catLabel} />
      )}
      {(view === 'all' || view === 'expense') && (
        <CategoryBreakdown title={L.topExpenseCats} entries={expenseCategoryBreakdown} total={expenses} color="bg-rose-400" catLabel={catLabel} />
      )}

      {/* Transactions list */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm mb-4">
        <div className="flex items-center justify-between p-4 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-800">
            {L.transactions} ({filtered.length})
          </h3>
          <button
            onClick={canExport
              ? () => exportToCSV(filtered, hasCustomRange ? `Report_${dateFrom}_to_${dateTo}_${view}` : selectedMonth === 'all' ? `All_${view}` : `Report_${selectedMonth}_${view}`, catLabel)
              : onOpenUpgrade}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl transition-all active:scale-95 ${
              canExport ? 'bg-emerald-500 hover:bg-emerald-600 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-500'
            }`}
          >
            {canExport ? <Download className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            {L.exportCSV}
          </button>
        </div>
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-sm">{L.noTransactions}</div>
        ) : (
          <div className="divide-y divide-slate-50 max-h-80 overflow-y-auto">
            {filtered.slice(0, 50).map(t => renderRow(t))}
          </div>
        )}
      </div>

      {/* Product / Order search report */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm mb-4">
        <div className="p-4 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 mb-1">
            <Package className="w-4 h-4 text-emerald-600" />
            {L.searchTitle}
          </h3>
          <p className="text-[11px] text-slate-400 mb-3">{L.searchHint}</p>
          <div className="relative">
            <Search className={`w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 ${isRtl ? 'right-3' : 'left-3'}`} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={L.searchPlaceholder}
              className={`w-full py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400 ${isRtl ? 'pr-9 pl-8' : 'pl-9 pr-8'}`}
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                title={L.clearSearch}
                aria-label={L.clearSearch}
                className={`absolute top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 ${isRtl ? 'left-3' : 'right-3'}`}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {search.trim() !== '' && (
          <>
            {searchResults.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">{L.noMatches}</div>
            ) : (
              <>
                <div className="grid grid-cols-3 gap-3 p-4 border-b border-slate-100">
                  <div className="bg-rose-50 rounded-xl p-2.5">
                    <p className="text-[9px] font-semibold text-rose-600 uppercase mb-0.5">{L.totalSpent}</p>
                    <p className="text-xs font-bold text-rose-700" dir="ltr">{fmt(searchSpent)}</p>
                  </div>
                  <div className="bg-emerald-50 rounded-xl p-2.5">
                    <p className="text-[9px] font-semibold text-emerald-600 uppercase mb-0.5">{L.totalReceived}</p>
                    <p className="text-xs font-bold text-emerald-700" dir="ltr">{fmt(searchReceived)}</p>
                  </div>
                  <div className={`rounded-xl p-2.5 ${searchReceived - searchSpent >= 0 ? 'bg-indigo-50' : 'bg-orange-50'}`}>
                    <p className="text-[9px] font-semibold text-indigo-600 uppercase mb-0.5">{L.netForItem}</p>
                    <p className={`text-xs font-bold ${searchReceived - searchSpent >= 0 ? 'text-indigo-700' : 'text-rose-600'}`} dir="ltr">
                      {fmt(searchReceived - searchSpent)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100">
                  <span className="text-xs text-slate-500">{searchResults.length} {L.matches}</span>
                  <button
                    onClick={canExport ? () => exportToCSV(searchResults, `Product_Report_${search.trim().replace(/[^a-z0-9]+/gi, '_')}`, catLabel) : onOpenUpgrade}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl transition-all active:scale-95 ${
                      canExport ? 'bg-slate-800 hover:bg-slate-900 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-500'
                    }`}
                  >
                    {canExport ? <Download className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                    {L.exportMatches}
                  </button>
                </div>
                <div className="divide-y divide-slate-50 max-h-80 overflow-y-auto">
                  {searchResults.map(t => renderRow(t))}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
