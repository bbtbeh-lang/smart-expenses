'use client';

import { useState } from 'react';
import { X, Download, Lock, FileSpreadsheet, FileDown, Eye } from 'lucide-react';
import { Translations } from '@/lib/translations';
import { Tier, Transaction, Lang } from '@/lib/types';
import { formatCurrency, resolveCategoryLabel, csvField, neutralizeCsvFormula } from '@/lib/utils';
import { supabase } from '@/lib/supabase';

interface TaxReportModalProps {
  tr: Translations;
  tier: Tier;
  // Grants temporary access to gated exports the same way an active gift
  // code unlocks manual entry (see app/api/subscription/route.ts's
  // hasManualAccess) — a free-tier user with a currently-redeemed code
  // gets PDF/CSV export too, on top of manual entry, without needing to
  // upgrade. This is purely additive to `tier === 'premium'`; it never
  // downgrades a paying user's access.
  hasGiftAccess: boolean;
  lang: Lang;
  transactions: Transaction[];
  onClose: () => void;
  onOpenUpgrade: () => void;
  customCategories?: Record<string, string>;
  customIncomeCategories?: Record<string, string>;
}

type Tab = 'summary' | 'ledger' | 'tax';

export default function TaxReportModal({ tr, tier, hasGiftAccess, lang, transactions: allTransactions, onClose, onOpenUpgrade, customCategories = {}, customIncomeCategories = {} }: TaxReportModalProps) {
  // BUG FIX: exports (PDF and CSV/Excel) were meant to be a paid-plan
  // feature per the in-app guide ("Downloading as CSV or PDF requires a
  // paid plan or an active gift code"), but only the CSV/Excel button
  // actually checked this — the PDF button below had no gate at all, so
  // every free-tier user could already download the tax report as a PDF
  // for free. `canExport` is the single source of truth both buttons
  // should check from here on.
  const canExport = tier === 'premium' || hasGiftAccess;
  const catLabel = (key: string) => resolveCategoryLabel(key, tr as unknown as Record<string, string>, customCategories, customIncomeCategories);
  const [activeTab, setActiveTab] = useState<Tab>('summary');
  const [pdfLoading, setPdfLoading] = useState(false);
  const [loadingReceiptId, setLoadingReceiptId] = useState<string | null>(null);

  const currentYear = new Date().getFullYear();
  // Transactions store dates as plain 'YYYY-MM-DD' strings (see
  // todayLocalDate in lib/utils.ts) specifically to avoid the
  // new Date("2026-07-27") UTC-midnight parsing bug — so we compare
  // the year as a string slice here too, instead of re-parsing with
  // `new Date(t.date)`, to stay consistent with that fix.
  const transactions = allTransactions.filter(t => t.date.slice(0, 4) === String(currentYear));

  const totalIncome = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const totalTax = transactions.filter(t => t.taxAmount).reduce((s, t) => s + (t.taxAmount || 0), 0);
  const netProfit = totalIncome - totalExpenses;

  // Per-category breakdown for the Tax tab — purely a re-grouping of data
  // the user already entered (amount + taxAmount per transaction). This
  // does NOT calculate any GST/HST/QST remittance figure; it just makes
  // the existing numbers easier for an accountant to work from, category
  // by category, instead of one lump total.
  const categoryBreakdown = (() => {
    const map: Record<string, { amount: number; tax: number }> = {};
    transactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        if (!map[t.category]) map[t.category] = { amount: 0, tax: 0 };
        map[t.category].amount += t.amount;
        map[t.category].tax += t.taxAmount || 0;
      });
    return Object.entries(map).sort((a, b) => b[1].amount - a[1].amount);
  })();

  const handleViewReceipt = async (tx: Transaction) => {
    if (!tx.receiptHash) return;
    setLoadingReceiptId(tx.id);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) return;
      const res = await fetch('/api/receipts/signed-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ receiptHash: tx.receiptHash }),
      });
      const data = await res.json();
      if (data.url) window.open(data.url, '_blank');
    } finally {
      setLoadingReceiptId(null);
    }
  };

  // Accountant-style monthly report: one block per month, numbered rows,
  // pre-tax / tax / total split out explicitly, and a subtotal row per
  // month plus a grand total at the end — the format she hands to her
  // bookkeeper, not just a flat transaction dump. Pre-tax amount is
  // derived as amount − taxAmount, since `amount` is stored as the
  // receipt's final total (see the OCR prompt) and `taxAmount` is the
  // tax portion within it, not an addition on top.
  const handleDownloadExcel = () => {
    const rows: string[][] = [];
    const monthNames = lang === 'FA'
      ? ['ژانویه', 'فوریه', 'مارس', 'آوریل', 'مه', 'ژوئن', 'ژوئیه', 'اوت', 'سپتامبر', 'اکتبر', 'نوامبر', 'دسامبر']
      : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    const expenseTx = transactions.filter(t => t.type === 'expense').slice().sort((a, b) => a.date.localeCompare(b.date));

    const byMonth = new Map<string, Transaction[]>();
    expenseTx.forEach(t => {
      const key = t.date.slice(0, 7); // YYYY-MM
      if (!byMonth.has(key)) byMonth.set(key, []);
      byMonth.get(key)!.push(t);
    });

    let grandPretax = 0, grandTax = 0, grandTotal = 0;

    Array.from(byMonth.keys()).sort().forEach(monthKey => {
      const monthTx = byMonth.get(monthKey)!;
      const monthLabel = monthNames[parseInt(monthKey.slice(5, 7), 10) - 1];

      rows.push([`Month ${monthLabel}`]);
      rows.push(['#', 'Description', 'Date', 'Store', 'Amount', 'Tax', 'Total', 'Document']);

      let mPretax = 0, mTax = 0, mTotal = 0;
      monthTx.forEach((tx, i) => {
        const tax = tx.taxAmount || 0;
        const pretax = tx.amount - tax;
        mPretax += pretax; mTax += tax; mTotal += tx.amount;
        const [y, mo, d] = tx.date.split('-');
        rows.push([
          String(i + 1),
          neutralizeCsvFormula(tx.description),
          `${d}/${mo}/${y}`,
          neutralizeCsvFormula(tx.merchant || ''),
          pretax.toFixed(2),
          tax.toFixed(2),
          tx.amount.toFixed(2),
          tx.receiptHash ? 'Yes' : '',
        ]);
      });

      rows.push(['', '', '', 'total', mPretax.toFixed(2), mTax.toFixed(2), mTotal.toFixed(2), '']);
      rows.push([]);
      grandPretax += mPretax; grandTax += mTax; grandTotal += mTotal;
    });

    rows.push(['', '', '', 'GRAND TOTAL', grandPretax.toFixed(2), grandTax.toFixed(2), grandTotal.toFixed(2), '']);

    // Summary rows
    rows.push([]);
    rows.push(['SUMMARY', '', '', '', '', '', '', '']);
    rows.push(['Total Income', '', '', '', '', '', '', String(totalIncome)]);
    rows.push(['Total Expenses', '', '', '', '', '', '', String(totalExpenses)]);
    rows.push(['Net Profit', '', '', '', '', '', '', String(netProfit)]);

    if (categoryBreakdown.length > 0) {
      rows.push([]);
      rows.push(['TAX BY CATEGORY', '', '', '', '', '', '', '']);
      rows.push(['Category', 'Total Expense', 'Total Tax', '', '', '', '', '']);
      categoryBreakdown.forEach(([cat, sums]) => {
        // BUG FIX: this used to only check `tr`, so any custom expense
        // category showed its raw internal key instead of the label the
        // person typed — on the report that goes straight to an accountant.
        const label = neutralizeCsvFormula(catLabel(cat));
        rows.push([label, String(sums.amount), String(sums.tax), '', '', '', '', '']);
      });
    }

    const NL = String.fromCharCode(10);
    // BUG FIX: this used to build each cell with JSON.stringify(c), which
    // escapes an internal quote as \" (backslash) — not valid CSV, where
    // RFC4180 requires doubling it ("") instead. A description containing
    // a literal quote character would silently corrupt the row's column
    // boundaries when opened in Excel. csvField does the correct escaping;
    // formula-injection neutralization already happened above, at push
    // time, for the specific free-text cells that needed it.
    const csvContent = rows.map(r => r.map(c => csvField(c)).join(',')).join(NL);
    // Leading UTF-8 BOM: without it, Excel on Windows opens this CSV using
    // the system locale's codepage instead of UTF-8, and Persian/French
    // characters (merchant names, category labels) render as mojibake.
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'finsnap-tax-report.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadPDF = async () => {
    setPdfLoading(true);
    try {
      // Load html2pdf.js via script tag so it never enters the webpack bundle
      if (!(window as any).html2pdf) {
        await new Promise<void>((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
          script.onload = () => resolve();
          script.onerror = () => reject(new Error('Failed to load html2pdf.js'));
          document.head.appendChild(script);
        });
      }
      const html2pdfFn = (window as any).html2pdf;
      const element = document.getElementById('tax-report-pdf-content');
      if (!element || !html2pdfFn) return;
      await html2pdfFn()
        .set({
          margin: 8,
          filename: 'finsnap-tax-report.pdf',
          html2canvas: { scale: 2, useCORS: true },
          jsPDF: { format: 'a4', orientation: 'portrait' },
        })
        .from(element)
        .save();
    } catch {
      // silently fall back
    } finally {
      setPdfLoading(false);
    }
  };

  const tabs: { id: Tab; label: string }[] = [
    { id: 'summary', label: tr.tabSummary },
    { id: 'ledger', label: tr.tabLedger },
    { id: 'tax', label: tr.tabTax },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-white rounded-t-3xl shadow-2xl z-50 max-h-[92vh] overflow-y-auto">
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-slate-200" />
        </div>

        <div className="px-5 pb-8 pt-2" id="tax-report-pdf-content">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center">
                <FileSpreadsheet className="w-4 h-4 text-teal-600" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900">{tr.taxReportTitle}</h2>
                <p className="text-xs text-slate-500">{tr.taxReportSub}</p>
              </div>
            </div>
            <button onClick={onClose} title={tr.closeModal} aria-label={tr.closeModal} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors">
              <X className="w-5 h-5 text-slate-500" />
            </button>
          </div>

          {/* Workbook Tab Bar */}
          <div className="flex items-center gap-1 mb-5 bg-slate-100 p-1 rounded-xl" dir="ltr">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all duration-150 ${activeTab === tab.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {activeTab === 'summary' && (
            <div className="space-y-3">
              <div className="bg-slate-50 rounded-2xl p-4">
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">{tr.fiscalYear} {currentYear}</div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">{tr.totalIncome}</span>
                    <span className="text-sm font-bold text-emerald-600" dir="ltr">{formatCurrency(totalIncome, lang, 2)}</span>
                  </div>
                  <div className="h-px bg-slate-200" />
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">{tr.totalExpenses}</span>
                    <span className="text-sm font-bold text-rose-500" dir="ltr">{formatCurrency(totalExpenses, lang, 2)}</span>
                  </div>
                  <div className="h-px bg-slate-200" />
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-800">{tr.netProfit}</span>
                    <span className={`text-base font-bold ${netProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`} dir="ltr">{formatCurrency(netProfit, lang, 2)}</span>
                  </div>
                </div>
              </div>
              <div className="bg-slate-50 rounded-2xl p-4">
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">{tr.transactionCount}</div>
                <div className="flex gap-3">
                  <div className="flex-1 bg-emerald-50 rounded-xl p-3 text-center">
                    <div className="text-lg font-bold text-emerald-600">{transactions.filter(t => t.type === 'income').length}</div>
                    <div className="text-xs text-emerald-600">{tr.income}</div>
                  </div>
                  <div className="flex-1 bg-rose-50 rounded-xl p-3 text-center">
                    <div className="text-lg font-bold text-rose-500">{transactions.filter(t => t.type === 'expense').length}</div>
                    <div className="text-xs text-rose-500">{tr.expense}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ledger' && (
            <div className="space-y-2">
              {transactions.length === 0 ? (
                <div className="text-center py-8 text-sm text-slate-400">No transactions yet.</div>
              ) : (
                transactions.slice().reverse().map(tx => (
                  <div key={tx.id} className="bg-slate-50 rounded-xl p-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full shrink-0 ${tx.type === 'income' ? 'bg-emerald-500' : 'bg-rose-400'}`} />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-slate-800 truncate">{tx.description}</div>
                        <div className="text-xs text-slate-500">{tx.date} · {catLabel(tx.category)}</div>
                      </div>
                      <div className={`text-sm font-bold shrink-0 ${tx.type === 'income' ? 'text-emerald-600' : 'text-rose-500'}`} dir="ltr">
                        {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount, lang, 2)}
                      </div>
                    </div>
                    {tx.items && tx.items.length > 0 && (
                      <div className="mt-2 ml-5 space-y-0.5 border-t border-slate-200 pt-2">
                        {tx.items.map((item, i) => (
                          <div key={i} className="flex justify-between text-xs text-slate-500">
                            <span>{item.name}</span>
                            <span dir="ltr">{formatCurrency(item.price, lang, 2)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    {tx.hasReceipt && (
                      <div className="shrink-0">
                        {tx.receiptHash ? (
                          <button
                            onClick={() => handleViewReceipt(tx)}
                            disabled={loadingReceiptId === tx.id}
                            className="flex items-center gap-1 text-xs text-teal-600 bg-teal-50 hover:bg-teal-100 px-1.5 py-0.5 rounded-md font-medium transition-colors"
                          >
                            <Eye className="w-3 h-3" />
                            {loadingReceiptId === tx.id ? '…' : tr.receiptScanned}
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-md font-medium">📎 {tr.receiptScanned}</span>
                        )}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'tax' && (
            <div className="space-y-3">
              <div className="bg-slate-50 rounded-2xl p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">{tr.totalTaxPaid}</span>
                  <span className="text-sm font-bold text-slate-800" dir="ltr">{formatCurrency(totalTax, lang, 2)}</span>
                </div>
                <div className="h-px bg-slate-200" />
                <p className="text-xs text-slate-400 leading-relaxed">{tr.taxLineExplainer}</p>
              </div>

              {categoryBreakdown.length > 0 && (
                <div className="bg-slate-50 rounded-2xl p-4">
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">{tr.taxByCategory}</div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wide px-0.5">
                      <span>{tr.categoryColumn}</span>
                      <span dir="ltr">{tr.totalExpenses} · {tr.totalTaxPaid}</span>
                    </div>
                    {categoryBreakdown.map(([cat, sums]) => (
                      <div key={cat} className="flex items-center justify-between bg-white rounded-xl px-3 py-2">
                        <span className="text-xs font-medium text-slate-700">{catLabel(cat)}</span>
                        <span className="text-xs font-semibold text-slate-600" dir="ltr">
                          {formatCurrency(sums.amount, lang, 2)} · {formatCurrency(sums.tax, lang, 2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2">
                <Lock className="w-3.5 h-3.5 text-amber-500 mt-0.5 shrink-0" />
                <p className="text-xs text-amber-700 leading-relaxed">{tr.taxDisclaimer}</p>
              </div>
            </div>
          )}

          <div className="mt-6 space-y-3">
            {canExport ? (
              <>
                <button
                  onClick={handleDownloadPDF}
                  disabled={pdfLoading}
                  className="w-full py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-sm shadow-lg shadow-slate-200 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-70"
                >
                  {pdfLoading ? (
                    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                    </svg>
                  ) : <FileDown className="w-4 h-4" />}
                  {tr.downloadPDF}
                </button>
                <button onClick={handleDownloadExcel} className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold rounded-xl text-sm shadow-lg shadow-emerald-200 flex items-center justify-center gap-2">
                  <Download className="w-4 h-4" />
                  {tr.downloadExcel}
                </button>
              </>
            ) : (
              <div className="space-y-3">
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2">
                  <Lock className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                  <p className="text-xs text-amber-700">{tr.downloadBlocked}</p>
                </div>
                <button
                  onClick={() => { onClose(); onOpenUpgrade(); }}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-xl text-sm shadow-lg shadow-amber-200 flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  {tr.upgradeToPremium}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
